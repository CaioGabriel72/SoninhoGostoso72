<?php

namespace App\Controllers;

class Contatos extends BaseController
{
    public function index()
    {
        $session = \Config\Services::session();
        $user = $session->get('logged');

        if(empty($user)){
            return redirect()->to('/');
        }

        $contatoModel = new \App\Models\contatoModel();
        $pessoas = $contatoModel->where('LOGIN', $user->LOGIN)->get()->getResult();
        $msg = "";

        if ($session->getFlashdata('msg')!==""){
            $msg = $session->getFlashdata('msg');
        }

        return view('contato/index', [
            'title'   => 'Contatos',
            'user'    => $user,
            'pessoas' => $pessoas,
            'msg'     => $msg
        ]);
    }

    public function contato($id)
    {
        $session = \Config\Services::session();
        $user = $session->get('logged');

        if(empty($user)){
            return redirect()->to('/');
        }

        $contatoModel = new \App\Models\contatoModel();
        $pessoa = $contatoModel->where('LOGIN', $user->LOGIN)->find(['ID_CONTATO' => $id]);

        if (sizeof($pessoa) < 1) {
            return redirect()->to('/contatos');
        }

        $enderecos = $contatoModel->infoEnderecos($id);
        $telefones = $contatoModel->infoTelefones($id);

        if (sizeof($pessoa) > 0)
        {
            $pessoa = $pessoa[0];
            return view('contato/pessoa', [
                'title'     => "$pessoa->NOME | Contato",
                'user'      => $user,
                'pessoa'    => $pessoa,
                'enderecos' => $enderecos,
                'telefones' => $telefones
            ]);
        }
    }

    public function inserir()
    {
        $session = \Config\Services::session();
        $user = $session->get('logged');

        if(empty($user)){
            return redirect()->to('/');
        }

        if (!empty($this->request->getPost()))
        {
            $contatoModel = new \App\Models\contatoModel();
            $enderecoModel = new \App\Models\enderecosModel();

            $dadosContato = [
                'NOME' => $this->request->getPost('NOME'),
                'DATA_NASC' => $this->request->getPost('DATA_NASC'),
                'LOGIN' => $user->LOGIN,
                'IMAGEM' => ""
            ];

            $dadosEmail = [
                'END_EMAIL' => $this->request->getPost('EMAIL')
            ];

            $dadosEndereco = [
                'RUA' => $this->request->getPost('RUA'),
                'NUMERO' => $this->request->getPost('NUMERO'),
                'BAIRRO' => $this->request->getPost('BAIRRO'),
                'CIDADE' => $this->request->getPost('CIDADE'),
                'CEP' => $this->request->getPost('CEP')
            ];

            $dadosTelefone = [
                'TELEFONE' => $this->request->getPost('TELEFONE')
            ];

            try {
                $contatoModel->save($dadosContato);

                // Dando upload na imagem e editando a coluna IMAGEM para o path criado
                $img = $this->request->getFile('IMAGEM');
                if ($img->isValid()) {
                    $path = 'img';
                    $id_contato = $contatoModel->get()->getResult()[sizeof($contatoModel->get()->getResult())-1]->ID_CONTATO;
                    $name = $id_contato . "." . $img->getClientExtension();
                    $fullpath = $path.'/'.$name;
                    if ($img->hasMoved() === false) {
                        $img->move($path, $name);
                    }
                } else {
                    $id_contato = $contatoModel->get()->getResult()[sizeof($contatoModel->get()->getResult())-1]->ID_CONTATO;
                    $fullpath = 'img/default_user.png';
                }
                $contatoModel->update($id_contato, ['IMAGEM' => $fullpath]);

                $enderecoModel->save($dadosEndereco);
                $contatoModel->insertEmail($dadosEmail);
                $contatoModel->insertContEnd();
                $contatoModel->insertTelefone($dadosTelefone);
                $msg = "<p class='alert alert-success'>Contato { <b>$dadosContato[NOME]</b> } inserido com sucesso!</p>";
            } catch (\Exception $e) {
                $msg = "<p class='alert alert-danger'>Error! $e</p>";
            }

            return redirect()->to('contatos')->with('msg', $msg);
        }
        return view('contato/form', [
            'title' => 'Adicionar Contato',
            'user' => $user
        ]);
    }

    public function remover($id="null") {
        $session = \Config\Services::session();
        $user = $session->get('logged');

        if(empty($user)){
            return redirect()->to('/');
        }

        if ($id === "null") {
            return redirect()->to('/contatos');
        }

        $contatoModel = new \App\Models\contatoModel();

        $nome = $contatoModel->find($id)->NOME;

        if ($contatoModel->find($id)->IMAGEM !== "" && $contatoModel->find($id)->IMAGEM !== "img/default_user.png") {
            unlink($contatoModel->find($id)->IMAGEM);
        }

        if ($contatoModel->deleteEndereco($id)  && $contatoModel->delete($id) ) {
            $msg = "<p class='alert alert-success'>Contato { <b>$nome</b> } removido com sucesso!</p>";
        }

        return redirect()->to('contatos')->with('msg', $msg);
    }

    /*public function mensagem()
    {
        $session = \Config\Services::session();
        $user = $session->get('logged');

        $dados = $session->getFlashdata('dados');
        if ($dados != ""){
            return view('contato/mensagem', [
                'title' => 'Contato Inserido!',
                'user' => $user,
                'dados' => $dados,
                'msg' => $dados['msg']
            ]);
        } else {
            return redirect()->to('contatos');
        }
    }*/
}