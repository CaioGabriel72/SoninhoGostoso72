<?php

namespace App\Controllers;

class Contatos extends BaseController
{
    public function index()
    {

    }
}