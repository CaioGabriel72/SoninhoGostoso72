<?php

namespace App\Controllers;

class Contatos extends BaseController
{
    public function index()
    {
        $session = \Config\Services::session();
        $user = $session->get('logged');
        if(empty($user)){
            return redirect()->to('/');
        }

        $contatoModel = new \App\Models\contatoModel();
        $pessoas = $contatoModel->get()->getResult();

        return view('contato/index', [
            'title'   => 'Contatos',
            'user'    => $user,
            'pessoas' => $pessoas
        ]);
    }

    public function contato($id)
    {
        $session = \Config\Services::session();
        $user = $session->get('logged');

        $contatoModel = new \App\Models\contatoModel();
        $pessoa = $contatoModel->find(['ID_CONTATO' => $id]);
        $enderecos = $contatoModel->infoEnderecos($id);
        $telefones = $contatoModel->infoTelefones($id);

        if (sizeof($pessoa) > 0)
        {
            $pessoa = $pessoa[0];
            return view('contato/pessoa', [
                'title'     => "$pessoa->NOME | Contato",
                'user'      => $user,
                'pessoa'    => $pessoa,
                'enderecos' => $enderecos,
                'telefones' => $telefones
            ]);
        }
    }
}