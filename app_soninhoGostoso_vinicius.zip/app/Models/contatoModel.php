<?php

namespace App\Models;

use CodeIgniter\Model;

class contatoModel extends Model
{
    protected $table         = 'CONTATO';
    protected $primaryKey    = 'ID_CONTATO';

    protected $allowedFields = ['ID_CONTATO', 'NOME', 'DATA_NASC', 'LOGIN', 'IMAGEM'];
    protected $returnType    = 'object';

    public function infoEnderecos($id)
    {
        $db = db_connect();
        return $db->table('CONTATO_ENDERECO')
                  ->where(['ID_CONTATO' => $id])
                  ->join('ENDERECOS', 'ENDERECOS.ID_ENDERECO = CONTATO_ENDERECO.ID_ENDERECO')
                  ->get()
                  ->getResult();
    }

    public function infoTelefones($id)
    {
        $db = db_connect();
        return $db->table('TELEFONES')
                  ->where(['ID_CONTATO' => $id])
                  ->get()
                  ->getResult();
    }
}