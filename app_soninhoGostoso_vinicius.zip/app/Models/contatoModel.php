<?php

namespace App\Models;

use CodeIgniter\Model;

class contatoModel extends Model
{
    protected $table         = 'CONTATO';
    protected $primaryKey    = 'ID_CONTATO';

    protected $allowedFields = ['ID_CONTATO', 'NOME', 'DATA_NASC', 'LOGIN', 'IMAGEM'];
    protected $returnType    = 'object';

    public function infoEnderecos($id)
    {
        $db = db_connect();
        return $db->table('CONTATO_ENDERECO')
                  ->where(['ID_CONTATO' => $id])
                  ->join('ENDERECOS', 'ENDERECOS.ID_ENDERECO = CONTATO_ENDERECO.ID_ENDERECO')
                  ->get()
                  ->getResult();
    }

    public function infoTelefones($id)
    {
        $db = db_connect();
        return $db->table('TELEFONES')
                  ->where(['ID_CONTATO' => $id])
                  ->get()
                  ->getResult();
    }

    public function insertEmail($dados)
    {
        $table = db_connect()->table('emails');

        $dados['ID_CONTATO'] = $this->find()[sizeof($this->find())-1]->ID_CONTATO;
        return $table->insert($dados);
    }

    public function insertContEnd()
    {
        $table = db_connect()->table('contato_endereco');
        $enderecoModel = db_connect()->table('enderecos');
        $contatoModel = db_connect()->table('contato');

        $dados = [
            'ID_ENDERECO' => $enderecoModel->get()->getResult()[sizeof($enderecoModel->get()->getResult())-1]->ID_ENDERECO,
            'ID_CONTATO' => $contatoModel->get()->getResult()[sizeof($contatoModel->get()->getResult())-1]->ID_CONTATO
        ];

        return $table->insert($dados);
    }

    public function insertTelefone($dados)
    {
        $table = db_connect()->table('telefones');

        $dados['ID_CONTATO'] = $this->find()[sizeof($this->find())-1]->ID_CONTATO;
        return $table->insert($dados);
    }

    public function deleteEndereco($id_contato)
    {
        $endereco = db_connect()->table('enderecos');
        $contEnd = db_connect()->table('contato_endereco');

        $rows = $contEnd->where('ID_CONTATO', $id_contato)
                ->get()
                ->getResult();
        
        foreach ($rows as $row) {
            $endereco->where('ID_ENDERECO', $row->ID_ENDERECO)
                     ->delete();
        }

        return true;
    }
}