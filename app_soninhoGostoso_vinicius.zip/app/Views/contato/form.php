<?= $this->extend('contato/modelo') ?>
<?= $this->section('form') ?>

<div class="default">
    <form method="post" action="<?php echo base_url('contato/adicionar'); ?>" enctype="multipart/form-data">
        <div>
            <label>NOME:</label>
                <input type="text" name="NOME" id="NOME"><br/>
            <label>DATA DE NASCIMENTO</label>
                <input type="date" name="DATA_NASC" id="DATA_NASC"><br/>
            <label>IMAGEM</label>
                <input type="file" name="IMAGEM" id="IMAGEM"><br/>
            <label>EMAIL:</label>
                <input type="text" name="EMAIL" id="EMAIL"><br/>
        </div>
        <div>
            <label>RUA</label>
                <input type="text" name="RUA" id="RUA"><br/>
            <label>BAIRRO</label>
                <input type="text" name="BAIRRO" id="BAIRRO"><br/>
            <label>NUMERO</label>
                <input type="number" name="NUMERO" id="NUMERO"><br/>
            <label>CIDADE</label>
                <input type="text" name="CIDADE" id="CIDADE"><br/>
            <label>CEP</label>
                <input type="text" name="CEP" id="CEP"><br/>
        </div>
        <div>
            <label>TELEFONE:</label>
            <input type="number" name="TELEFONE" id="TELEFONE"><br/>
        </div>

        <input type="submit" value="SALVAR">
    </form>
</div>

<?= $this->endSection() ?>