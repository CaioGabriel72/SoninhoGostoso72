<?= $this->extend('contato/modelo') ?>
<?= $this->section('form') ?>

<div class="default">
    <form method="post" action="<?= base_url('contato/adicionar'); ?>">
    <label>
        NOME:
    </label>
    <input type="text" name="NOME" id="NOME"><br/>
    <label>
        DATA DE NASCIMENTO
    </label>
    <input type="date" name="DATA_NASC" id="DATA_NASC"><br/>
    <label>
        LOGIN:
    </label>
    <input type="text" name="LOGIN" id="LOGIN"><br/>
    <label>
        IMAGEM
    </label>
    <input type="file" name="IMAGEM" id="IMAGEM"><br/>

    <input type="submit" value="SALVAR">

    </form>
</div>

<?= $this->endSection() ?>