<?= $this->extend('contato/modelo')?>
<?= $this->section('form')?>
<div class="align-center">
    <?= $msg; ?>
    <?php echo "<pre>". print_r($dados, true) . "</pre>"; ?>
</div>
<?= $this->endSection() ?>