<?= $this->extend('modelo') ?>
<?= $this->section('login') ?>

<div class="default login">
    <?= !empty($msg) ? $msg : "" ?>
    <h2>Login</h2>

    <form action=<?= base_url('verificar') ?> method="post">
        <label for="login">Username:</label><br>
        <input type="text" name="login" id="login">

        <br><br>

        <label for="senha">Senha:</label><br>
        <input type="password" name="senha" id="senha">
        <br>

        <input type="submit" value="Logar">
    </form>
</div>

<?= $this->endSection() ?>