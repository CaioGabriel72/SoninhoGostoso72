<?= $this->extend('login/modelo') ?>
<?= $this->section('login') ?>

<div class="default text-center login">
    <?= !empty($msg) ? $msg : "" ?>

    <h2>SAUDAÇÃO<br>(BEM-VINDO(A) DE VOLTA)</h2>
    <h6>Entre na sua conta</h6><br><br>

    <form action=<?= base_url('verificar') ?> method="post">
        <label for="login">Username:</label><br>
        <input type="text" name="login" id="login">

        <br><br>

        <label for="senha">Senha:</label><br>
        <input type="password" name="senha" id="senha">
        <br>

        <input type="submit" value="Logar">
    </form>
</div>

<?= $this->endSection() ?>