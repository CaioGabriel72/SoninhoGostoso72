<?php

namespace App\Controllers;

class Login extends BaseController
{
    public function index()
    {
        $session = \Config\Services::session();
        $user = $session->get('logged');

        if(!empty($user)){
            return redirect()->to('contatos');
        }

        return view('login/login', [
            'title' => 'Login'
        ]);
    }

    public function verificar()
    {
        $msg = "";
        if (!empty($this->request->getPost()))
        {
            define('SECRET', pack('a16', 'senhamuitodificil'));
            define('SECRET_1', pack('a16', 'dificilmesmo'));
            $encrypted = $this->request->getVar('senha');
            // Para ativar a criptografia descomente as linhas seguintes;
             $encrypted = openssl_encrypt($this->request->getVar('senha'), 'aes-256-cbc', SECRET, 0, SECRET_1);
            // return print_r(openssl_encrypt('senha', 'aes-256-cbc', SECRET, 0, SECRET_1));

            $pass = ($this->request->getVar('senha') !== "") ? $encrypted : "";

            $dados = [
                'login' => $this->request->getVar('login'),
                'senha' => $pass
            ];

            $validation = \Config\Services::validation();
            $validation->run($dados, 'login');
            $msg = "*". implode( '<br>*', $validation->getErrors() );
            $msg = '<p class="alert alert-danger">'. $msg .'</p>';

            $usuarioModel = new \App\Models\usuarioModel();

            if (sizeof( $usuarioModel->verificarLogin($dados['login'], $dados['senha'])) > 0)
            {
                $session = \Config\Services::session();
                $session->set('logged', $usuarioModel->verificarLogin($dados['login'], $dados['senha'])[0]);
                return redirect()->to('contatos');
            } else {
                $msg = sizeof($validation->getErrors()) < 1 ? '<p class="alert alert-danger">*Login/Senha incorretos!</p>' : $msg;
                return view('login/login', [
                    'title' => 'Login',
                    'msg'   => $msg
                ]);
            }
        }   
    }

    public function logout()
    {
        $session = \Config\Services::session();
        $session->destroy();

        return redirect()->to('/');
    }

    public function cadastro(){
        return view('login/cadastro',['title' => 'Cadastro']);

    }

    public function cadastrar(){

    //    if(){
            

        $usuarioModel = new \App\Models\usuarioModel();

        $senha = $this->request->getPost('SENHA');

        define('SECRET', pack('a16', 'senhamuitodificil'));
        define('SECRET_1', pack('a16', 'dificilmesmo'));

        $encrypted = openssl_encrypt($senha, 'aes-256-cbc', SECRET, 0, SECRET_1);
        
        $usuarioDados = [
            'LOGIN' => $this->request->getPost('LOGIN'),
            'SENHA' => $encrypted
        ];
            
        $usuarioModel->save($usuarioDados);
    //}
    
}  

    /*public function cadastrar()
    {
        $msg = "";
        return view('login/cadastro');
    }*/
}